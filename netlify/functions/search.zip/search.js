var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/search.ts
var search_exports = {};
__export(search_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_exports);
var INDEX_NAME = "survey-questions";
var SEARCH_API_VERSION = "2024-07-01";
var AOAI_API_VERSION = "2024-02-01";
var MAX_TOP = 50;
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
async function getEmbedding(text) {
  const endpoint = (process.env.AOAI_ENDPOINT ?? "").replace(/\/$/, "");
  const deployment = process.env.AOAI_EMBED_DEPLOYMENT ?? "";
  const key = process.env.AOAI_KEY ?? "";
  const url = `${endpoint}/openai/deployments/${deployment}/embeddings?api-version=${AOAI_API_VERSION}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "api-key": key
    },
    body: JSON.stringify({ input: text })
  });
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`AOAI embeddings error ${res.status}: ${body}`);
  }
  const json = await res.json();
  return json.data[0].embedding;
}
function buildFilter(filters) {
  const clauses = ["doc_type eq 'question'"];
  if (filters) {
    for (const [field, value] of Object.entries(filters)) {
      if (value === null || value === void 0) continue;
      if (typeof value === "string") {
        const escaped = value.replace(/'/g, "''");
        clauses.push(`${field} eq '${escaped}'`);
      } else if (typeof value === "number" || typeof value === "boolean") {
        clauses.push(`${field} eq ${value}`);
      }
    }
  }
  return clauses.join(" and ");
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  const requiredEnv = [
    "SEARCH_ENDPOINT",
    "SEARCH_QUERY_KEY",
    "AOAI_ENDPOINT",
    "AOAI_KEY",
    "AOAI_EMBED_DEPLOYMENT"
  ];
  for (const key of requiredEnv) {
    if (!process.env[key]) {
      console.error(`[search] Missing env var: ${key}`);
      return {
        statusCode: 500,
        headers: CORS_HEADERS,
        body: JSON.stringify({ error: `Server configuration error: missing ${key}` })
      };
    }
  }
  let body;
  try {
    body = JSON.parse(event.body ?? "{}");
  } catch {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Invalid JSON body" })
    };
  }
  const { query, filters, top = 10 } = body;
  if (!query || typeof query !== "string" || !query.trim()) {
    return {
      statusCode: 400,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "query is required (non-empty string)" })
    };
  }
  const trimmedQuery = query.trim();
  const clampedTop = Math.min(Math.max(1, Number(top) || 10), MAX_TOP);
  let vector;
  try {
    vector = await getEmbedding(trimmedQuery);
    console.log(
      `[search] embedding OK \u2014 dims=${vector.length} query="${trimmedQuery.slice(0, 60)}"`
    );
  } catch (err) {
    console.error("[search] Embedding generation failed:", err);
    return {
      statusCode: 502,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Failed to generate query embedding" })
    };
  }
  const searchEndpoint = (process.env.SEARCH_ENDPOINT ?? "").replace(/\/$/, "");
  const searchKey = process.env.SEARCH_QUERY_KEY ?? "";
  const searchUrl = `${searchEndpoint}/indexes/${INDEX_NAME}/docs/search?api-version=${SEARCH_API_VERSION}`;
  const filter = buildFilter(filters);
  const searchPayload = {
    search: trimmedQuery,
    vectorQueries: [
      {
        kind: "vector",
        vector,
        fields: "content_vector",
        k: 50,
        exhaustive: false
      }
    ],
    filter,
    select: [
      "id",
      "survey_id",
      "survey_name",
      "survey_year",
      "pollster",
      "language",
      "variable",
      "question_text",
      "response_options",
      "var_type",
      "is_sociodemo",
      "sociodemo_type",
      "concepts",
      "themes",
      "tags",
      "n_respondents"
    ].join(","),
    top: clampedTop
  };
  console.log(`[search] AI Search \u2014 filter="${filter}" top=${clampedTop}`);
  let searchResult;
  try {
    const res = await fetch(searchUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-key": searchKey
      },
      body: JSON.stringify(searchPayload)
    });
    if (!res.ok) {
      const errBody = await res.text();
      throw new Error(`AI Search error ${res.status}: ${errBody}`);
    }
    searchResult = await res.json();
  } catch (err) {
    console.error("[search] AI Search request failed:", err);
    return {
      statusCode: 502,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "Search request failed" })
    };
  }
  const results = searchResult.value ?? [];
  return {
    statusCode: 200,
    headers: CORS_HEADERS,
    body: JSON.stringify({
      results,
      count: results.length
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
